# Customizer Typography

This plugin is a proof-of-concept and testing tool primarily for two things:

* Testing a customizer control class to handle typography.
* Tying multiple customize settings to a single control.

## How to use

This plugin creates a "Typography" panel in the customizer.  It lets you set some stuff.  It's plug-n-play, so give it a try.

## Notes

This is a developer tool.

I'll write more here later. :)

## Screenshots

![Customizer Typography Plugin Preview](https://raw.githubusercontent.com/justintadlock/customizer-typography/master/screenshot-1.png)